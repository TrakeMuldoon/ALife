# Contribute to the Win2D samples project

These Win2D samples are exported from the master Win2D repo. This can be found
at http://github.com/Microsoft/Win2D. Currently we are only accepting pull
requests to http://github.com/Microsoft/Win2D.
