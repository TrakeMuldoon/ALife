This folder contains custom pixel shaders for use by PixelShaderEffect.

The *.hlsl files contain HLSL shader source code. After editing these shaders,
run CompileShaders.cmd from a Developer Command Prompt for VS2017.
This will recompile them, generating the *.bin output binaries.

The *.bin files are included as part of Example Gallery.
